package com.example.braintrainer;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    String questNumber1, questNumber2;
    Button btnPurple, btnRed, btnSmarald, btnGrey, btnYellow, btnGreen, btnReplay , btnStartGAme;
    TextView textViewQuest, textViewMessage;
    ArrayList<Integer> valuesNumbers ;
    int numberOfQuests , numberOfCorrectAnswer = 0;

    public void onStartGameButtonClick( View view ) {

        btnStartGAme.setVisibility(View.INVISIBLE);

        btnPurple.setVisibility(View.VISIBLE);
        btnRed.setVisibility(View.VISIBLE);
        btnSmarald.setVisibility(View.VISIBLE);
        btnGrey.setVisibility(View.VISIBLE);
        btnYellow.setVisibility(View.VISIBLE);
        btnGreen.setVisibility(View.VISIBLE);
        textViewQuest.setVisibility(View.VISIBLE);

        btnGreen.setText(numberOfCorrectAnswer + "/" + numberOfQuests);

        countDownTimerButton();

    }

    public void onAnswerButtonClick( View view ) {

        Button button = (Button) view;

        int result = Integer.parseInt(questNumber1) + Integer.parseInt(questNumber2);

        if ( button.getText().equals(Integer.toString(result))){

            numberOfQuests++;
            numberOfCorrectAnswer ++ ;

            textViewMessage.setVisibility(View.INVISIBLE);

        } else {

            numberOfQuests++;

            textViewMessage.setVisibility( View.VISIBLE ) ;

        }

        btnGreen.setText(numberOfCorrectAnswer + "/" + numberOfQuests);

        generateRandomNumbersForQuest();
        valuesNumbers = generateRandomNumbersForAnswer();

        putTextOnAnswerButton(btnPurple);
        putTextOnAnswerButton(btnRed);
        putTextOnAnswerButton(btnSmarald);
        putTextOnAnswerButton(btnGrey);

    }

    public void onReplayButtonCLick( View view ) {

        btnPurple.setEnabled(true);
        btnRed.setEnabled(true);
        btnSmarald.setEnabled(true);
        btnGrey.setEnabled(true);
        textViewMessage.setVisibility(View.INVISIBLE);
        btnReplay.setVisibility(View.INVISIBLE);

        numberOfQuests = 0;
        numberOfCorrectAnswer = 0 ;

        btnGreen.setText(numberOfCorrectAnswer + "/" + numberOfQuests);

        generateRandomNumbersForQuest();
        valuesNumbers = generateRandomNumbersForAnswer();

        putTextOnAnswerButton(btnPurple);
        putTextOnAnswerButton(btnRed);
        putTextOnAnswerButton(btnSmarald);
        putTextOnAnswerButton(btnGrey);

        countDownTimerButton();
    }

    public void countDownTimerButton() {

        new CountDownTimer(20000,1000){

            @Override
            public void onTick(long l) {

                btnYellow.setText((int) l / 1000 + "s");

            }

            @Override
            public void onFinish() {

                btnPurple.setEnabled(false);
                btnRed.setEnabled(false);
                btnSmarald.setEnabled(false);
                btnGrey.setEnabled(false);
                textViewMessage.setText("Time is over ! Replay?");
                textViewMessage.setVisibility(View.VISIBLE);
                btnReplay.setVisibility(View.VISIBLE);

            }

        }.start();
    }

    public void putTextOnAnswerButton( Button button ) {

        int numbersSize = valuesNumbers.size();

        int i = new Random().nextInt(numbersSize);

        if (button.getText().equals("") || !button.getText().equals("") ) {

            button.setText(valuesNumbers.get(i).toString());
            valuesNumbers.remove(i);

        }
    }

    public void generateRandomNumbersForQuest() {

        questNumber1 = String.valueOf(new Random().nextInt((50 - 1) + 1) + 1);
        questNumber2 = String.valueOf(new Random().nextInt((50 - 1) + 1) + 1);

        textViewQuest.setText(questNumber1 + " + " + questNumber2);

    }

    public ArrayList<Integer> generateRandomNumbersForAnswer() {

        int max, min;
        ArrayList<Integer> numbers = new ArrayList<Integer>();

        generateRandomNumbersForQuest();

        if (Integer.parseInt(questNumber1) <= Integer.parseInt(questNumber2)) {

            min = Integer.parseInt(questNumber1);
            max = Integer.parseInt(questNumber2);

        } else {

            min = Integer.parseInt(questNumber2);
            max = Integer.parseInt(questNumber1);

        }

        numbers.add(new Random().nextInt((max - min) + 1) + min);
        numbers.add(new Random().nextInt((max - min) + 1) + min);
        numbers.add(new Random().nextInt((max - min) + 1) + min);
        numbers.add(max + min);

        return numbers;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnStartGAme = findViewById(R.id.btnStartGame);
        btnPurple = findViewById(R.id.btnPurple);
        btnRed = findViewById(R.id.btnRed);
        btnSmarald = findViewById(R.id.btnSmarald);
        btnGrey = findViewById(R.id.btnGrey);
        btnYellow = findViewById(R.id.btnTimer);
        btnGreen = findViewById(R.id.btnScore);
        btnReplay = findViewById(R.id.btnReplay);
        textViewQuest = findViewById(R.id.questTextView);
        textViewMessage = findViewById(R.id.messageTextView);

        valuesNumbers = generateRandomNumbersForAnswer();

        btnGreen.setEnabled(false);
        btnYellow.setEnabled(false);

        putTextOnAnswerButton(btnPurple);
        putTextOnAnswerButton(btnRed);
        putTextOnAnswerButton(btnSmarald);
        putTextOnAnswerButton(btnGrey);

    }
}